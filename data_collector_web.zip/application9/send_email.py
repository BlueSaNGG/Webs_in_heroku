#不用email作为py名称，有默认module叫做email
from email.mime.text import MIMEText
import smtplib

def send_email(email,height,average_height,count):
    from_email="bluesangg@163.com"
    from_password="QTSLBFNLPNKYIKDG"
    to_email=email #要送达的email为email

    subject="Height data"
    message="Hey there, your height is <strong>%s</strong>. Average height of all is <strong>%s</strong> and that is calculate out <strong>%s</strong> of people" % (height,average_height,count)

    msg=MIMEText(message,'html') #将message作为html
    msg["Subject"]=subject
    msg['To']=to_email
    msg['From']=from_email

    qmail=smtplib.SMTP_SSL('smtp.163.com',465)
    qmail.ehlo()
    #qmail.starttls()
    qmail.login(from_email,from_password)
    qmail.send_message(msg)