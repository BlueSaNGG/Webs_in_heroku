from flask import Flask,render_template,request         #得到email by request
from flask_sqlalchemy import SQLAlchemy
from send_email import send_email
from sqlalchemy.sql import func
#表示SQLAlchmy在flask的文件中
app=Flask(__name__)

#给出sql的连接地址和方式
#URI = 'postgresql://用户名:密码@localhost/database的名称'

#将URI变为heroku的database
#app.config['SQLALCHEMY_DATABASE_URI']='postgresql://postgres:COco315500@localhost/height_collector'
app.config['SQLALCHEMY_DATABASE_URI']='postgres://jsuhsogkhsjbkp:b66a902cce195156fc2b029a77fe0dab21fde2c4f7c7a734eb00d117e2ac716d@ec2-18-214-211-47.compute-1.amazonaws.com:5432/d7a2ria0cdejfb?sslmode=require'
#创建一个SQLobejct
db=SQLAlchemy(app)
 
#创建一个调用SQL的model
class Data(db.Model):  #继承
    #创建table：name
    __tablename__='data'
    #columns     #id类型为integer
    id=db.Column(db.Integer,primary_key=True)
    email_=db.Column(db.String(120),unique=True)  #只接受120个字符以下的字符串,且不存在相同邮箱
    height_=db.Column(db.Integer)      

    def __init__(self,email_,height_):
        self.email_=email_
        self.height_=height_



@app.route("/")
def index():
    return render_template("index.html")

#request可得到该页面的methods
@app.route("/success",methods=["POST"]) #传入methods
def success():
    #加入对邮箱的抓取
    if request.method=='POST':  #若按了按钮进入success
        email=request.form['email_name'] #得到form["email_name"]
        height=request.form["height_name"]
        #检查database 中 email是否重复
        #添加邮件
        if db.session.query(Data).filter(Data.email_==email).count()==0:#columns中的email是否与当前email相同                                        
            data=Data(email,height) #init函数
            db.session.add(data) #传入string无效 #需要传入Data对象
            db.session.commit()  #commit changes
            average_height=db.session.query(func.avg(Data.height_)).scalar()
            average_height=round(average_height,2) #保留1位小数
            count=db.session.query(Data.height_).count()
            send_email(email,height,average_height,count)  #建立send_email函数
            return render_template("success.html")
        return render_template('index.html',text="Seems like we've got something from that eamil address already!")

if __name__ =='__main__':
    app.debug=True
    app.run(port=5001)