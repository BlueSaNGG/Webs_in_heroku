from flask import Flask,render_template,request,send_file         #得到email by request
#from werkzeug import secure_filename
from werkzeug.utils import secure_filename
import pandas  #存放csv
from geopy.geocoders import ArcGIS  #添加经纬度
import datetime #防止同时传入相同name的文件


app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/submit', methods=['POST'])
def submit():
    global filename
    if request.method=='POST':
        try:
            file=request.files["file"]  #input里的file name
            #file.save(secure_filename("upload"+file.filename))  #防止含攻击代码的文件名
            #with open("upload"+file.filename) as f:
            #    data=pandas.read_csv(f)
            data=pandas.read_csv(file)
            try:
                nom=ArcGIS()
                data["Coordinates"]=data["Address"].apply(nom.geocode)
                data["Latitude"]=data["Coordinates"].apply(lambda x:x.latitude if x != None else None)
                data["Longitude"]=data["Coordinates"].apply(lambda x:x.longitude if x != None else None)
                data=data.drop(['Coordinates'],axis=1)
                filename=datetime.datetime.now().strftime("uploads/%Y-%m-%d-%H-%M-%S-%f"+".csv")
                #data.to_csv("upload"+file.filename)
                data.to_csv(filename,index=None)
                return render_template('home.html',btn="download.html",warning="success! You can download the table!",text=data.to_html())
            except:
                return render_template('home.html',warning="Seems like we have some problems ><<br>Please check your Address columns and try again!")
        except:
            return render_template('home.html',warning="No file uploaded!")
@app.route('/download')
def download():
    #return render_template('home.html',text="hello!")
    return send_file(filename, attachment_filename="Yourfile.csv",as_attachment=True)  #file需要设为全局变量

if __name__ =='__main__':
    app.debug=True
    app.run(port=5001)